import json

f = open('full.json')
data = json.load(f)

sample = data[:1000]
sample = json.dumps(sample)
f2 = open('bcsample.json', 'w')
f2.write(sample)
